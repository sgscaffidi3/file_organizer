 python.exe .\CodeStats.py
2025-12-18 22:06:26.153507 CodeStats.py:CodeStats.__init__() : self.Initialized == False
2025-12-18 22:06:26.154507 CodeStats.py:CodeStats.__init__() : self.Initialized == True
2025-12-18 22:06:26.155510 CodeStats.py:<module>.__main__() CodeStats Initialization Status : Success
2025-12-18 22:06:26.380371 CodeStats.py:<module>.__main__() Number of Python files: 24
2025-12-18 22:06:26.382372 CodeStats.py:<module>.__main__() Number of class statements: 22
2025-12-18 22:06:26.383894 CodeStats.py:<module>.__main__() Number of def statements: 130
2025-12-18 22:06:26.383894 CodeStats.py:<module>.__main__() Number of lines of code: 2667
2025-12-18 22:06:26.384912 CodeStats.py:<module>.__main__() Avg function size (loc): 20.515384615384615
2025-12-18 22:06:26.385913 CodeStats.py:<module>.__main__() Avg class size (loc): 121.22727272727273
2025-12-18 22:06:26.386648 CodeStats.py:<module>.__main__() Avg class size (defs): 5.909090909090909
(venv) PS C:\sandbox\sgscaffidi3\file_organizer\file_organizer> 
